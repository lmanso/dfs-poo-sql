-- Adminer 4.7.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `app_db` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `app_db`;

DROP TABLE IF EXISTS `characters`;
CREATE TABLE `characters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `health` int(11) NOT NULL,
  `mana` int(11) DEFAULT NULL,
  `energy` int(11) DEFAULT NULL,
  `power` int(11) NOT NULL,
  `speed` int(11) NOT NULL,
  `weapon` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `race_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`(50)),
  KEY `role_id` (`role_id`),
  KEY `race_id` (`race_id`),
  CONSTRAINT `characters_ibfk_3` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `characters_ibfk_4` FOREIGN KEY (`race_id`) REFERENCES `races` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `characters` (`id`, `img`, `name`, `gender`, `health`, `mana`, `energy`, `power`, `speed`, `weapon`, `race_id`, `role_id`) VALUES
(6,	'https://static.bladeandsoul.com/img/game/races/overview/race_expanded_top_01_gon_hover.png',	'Hank',	'Homme',	170,	NULL,	300,	100,	40,	'',	1,	4),
(7,	'jhjhkhhj',	'jhdskjhfdfkjghdfkjghfsjgdhfk',	'Femme',	300,	200,	80,	50,	80,	'Trident',	4,	1),
(33,	'https://picsum.photos/200/100gggf',	'fhfhfhff',	'homme',	10,	10,	10,	10,	10,	'Rouleau de pÃ¢tisserie',	4,	4);

DROP TABLE IF EXISTS `races`;
CREATE TABLE `races` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `races` (`id`, `name`) VALUES
(1,	'Elfe'),
(2,	'Orc'),
(3,	'Human'),
(4,	'Pixies');

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `roles` (`id`, `name`) VALUES
(1,	'Mage'),
(2,	'Priest'),
(3,	'Knight'),
(4,	'Hunter'),
(5,	'Rogue'),
(6,	'Warrior'),
(7,	'Paladin');

-- 2019-09-26 09:40:41
